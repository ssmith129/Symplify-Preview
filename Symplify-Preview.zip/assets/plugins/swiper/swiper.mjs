/**
 * Swiper 11.1.0
 * Most modern mobile touch slider and framework with hardware accelerated transitions
 * https://swiperjs.com
 *
 * Copyright 2014-2024 Vladimir Kharlampidi
 *
 * Released under the MIT License
 *
 * Released on: March 28, 2024
 */

export { S as Swiper, S as default } from './shared/swiper-core.mjs';
